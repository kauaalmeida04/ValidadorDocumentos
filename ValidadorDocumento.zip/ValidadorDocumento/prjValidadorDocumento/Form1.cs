﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace prjValidadorDocumento
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnValidar_Click(object sender, EventArgs e)
        {
            if (txtCPF.Text != string.Empty)
            {
                TestarCPF();
            }
            if (txtCNPJ.Text != string.Empty)
            {
                TestarCNPJ();
            }
        }
        private void TestarCNPJ()
        {
            PessoaJuridica p = new PessoaJuridica(txtNome.Text,
                 txtEndereco.Text, txtCNPJ.Text);
            if (p.Validar())
            {
                lbResultado.Text = String.Format(
                    "Pessoa: {0}\n documento:{1}\n teste:{2}"
                    , p.Nome, p.CNPJ, "Documento validado");
                lstClientes.Items.Add(p);
            }
            else
            {
                lbResultado.Text = String.Format(
                    "Pessoa:{0}\n documento:{1}\n teste: {2}"
                    , p.Nome, p.CNPJ, "Documento invalido");
            }
        }
        private void TestarCPF()
        {
            PessoaFisica p = new PessoaFisica(txtNome.Text,
                txtEndereco.Text, txtCPF.Text);
            if (p.Validar())
            {
                lbResultado.Text = String.Format(
                    "Pessoa: {0}\n documento:{1}\n teste:{2}"
                    , p.Nome, p.CPF, "Documento validado");
                lstClientes.Items.Add(p);
            }
            else
            {
                lbResultado.Text = String.Format(
                    "Pessoa:{0}\n documento:{1}\n teste: {2}"
                    , p.Nome, p.CPF, "Documento invalido");
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            lstClientes.DisplayMember = "Nome";
            lstClientes.ValueMember = "Endereco";
        }
    }
}
